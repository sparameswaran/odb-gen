. ../go.env 
./gen_manifest.py generate-manifest
