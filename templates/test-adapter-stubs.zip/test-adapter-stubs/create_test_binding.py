#!/usr/bin/env python

from subprocess import call
from sys import argv

with open("./bosh-vms.json", "r") as myfile:
    bosh_vms = myfile.read().replace('\n', ' ').replace('\r', '')

#with open("test-adapter-stubs/params.json", "r") as myfile:
#    params = myfile.read().replace('\n', ' ').replace('\r', '')

with open("./manifest.json", "r") as myfile:
    manifest = myfile.read().replace('\n', ' ').replace('\r', '')

with open("./request.json", "r") as myfile:
    requestParams = myfile.read().replace('\n', ' ').replace('\r', '')

#with open("test-adapter-stubs/service-releases.json", "r") as myfile:
#    service_releases = myfile.read().replace('\n', ' ').replace('\r', '')

#call(['go', 'run', '../src/PRODUCT-service-adapter/cmd/service-adapter/main.go', argv[1], '3412323i', bosh_vms, manifest, requestParams ]) 
call(['go', 'run', '../src/PRODUCT-service-adapter/cmd/service-adapter/main.go', argv[1], '3412323i', bosh_vms, manifest, '{}' ]) 

